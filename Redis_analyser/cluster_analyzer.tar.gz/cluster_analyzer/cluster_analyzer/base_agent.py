"""Base class all analysis agents inherit from."""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from .models import Finding


class BaseAgent(ABC):
    """An agent inspects a snapshot and emits Findings.

    Collection is deterministic (Python against the live cluster).
    Agents only reason over the collected snapshot — no network calls here —
    which makes them unit-testable and reproducible.
    """

    name: str = "base"

    @abstractmethod
    def analyze(self, redis_snapshot: dict[str, Any], elastic_snapshot: dict[str, Any]) -> list[Finding]:
        ...

    # Small helpers most agents want.
    @staticmethod
    def _safe_int(v: Any, default: int = 0) -> int:
        try:
            return int(v)
        except (TypeError, ValueError):
            return default

    @staticmethod
    def _safe_float(v: Any, default: float = 0.0) -> float:
        try:
            return float(v)
        except (TypeError, ValueError):
            return default
