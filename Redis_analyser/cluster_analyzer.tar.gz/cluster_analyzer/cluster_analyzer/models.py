"""Shared data models used across collectors and agents."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any


class Severity(str, Enum):
    CRITICAL = "CRITICAL"   # production-impacting, fix now
    HIGH = "HIGH"           # likely to cause incidents soon
    MEDIUM = "MEDIUM"       # efficiency / reliability improvement
    LOW = "LOW"             # nice-to-have / hygiene
    INFO = "INFO"           # observation, no action needed


class Area(str, Enum):
    CAPACITY = "capacity"
    LATENCY = "latency"
    TOPOLOGY = "topology"
    CONFIG = "config"
    WORKLOAD = "workload"
    RESILIENCE = "resilience"


# Rough impact/likelihood weights per severity, used for ranking.
SEVERITY_SCORE = {
    Severity.CRITICAL: 100,
    Severity.HIGH: 60,
    Severity.MEDIUM: 30,
    Severity.LOW: 10,
    Severity.INFO: 1,
}


@dataclass
class Finding:
    agent: str
    system: str                       # "redis" | "elasticsearch"
    area: Area
    severity: Severity
    title: str
    detail: str                       # what was observed, with numbers
    recommendation: str               # concrete next action
    evidence: dict[str, Any] = field(default_factory=dict)
    # Optional override — if the agent has strong priors about impact.
    score_override: int | None = None

    @property
    def score(self) -> int:
        return self.score_override if self.score_override is not None else SEVERITY_SCORE[self.severity]

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["area"] = self.area.value
        d["severity"] = self.severity.value
        d["score"] = self.score
        return d


@dataclass
class ReportBundle:
    generated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    redis_snapshot: dict[str, Any] = field(default_factory=dict)
    elastic_snapshot: dict[str, Any] = field(default_factory=dict)
    findings: list[Finding] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def add(self, finding: Finding) -> None:
        self.findings.append(finding)

    def to_dict(self) -> dict[str, Any]:
        return {
            "generated_at": self.generated_at.isoformat(),
            "redis_snapshot": self.redis_snapshot,
            "elastic_snapshot": self.elastic_snapshot,
            "findings": [f.to_dict() for f in self.findings],
            "errors": self.errors,
        }
