"""Elasticsearch snapshot collector."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

try:
    from elasticsearch import Elasticsearch
except ImportError:
    Elasticsearch = None  # raised on collect()

log = logging.getLogger(__name__)


@dataclass
class ElasticConnectionConfig:
    hosts: list[str] = field(default_factory=lambda: ["http://localhost:9200"])
    username: str | None = None
    password: str | None = None
    api_key: str | None = None
    verify_certs: bool = True
    request_timeout: float = 10.0


class ElasticCollector:
    def __init__(self, cfg: ElasticConnectionConfig):
        if Elasticsearch is None:
            raise RuntimeError("elasticsearch not installed. pip install elasticsearch")
        self.cfg = cfg
        self._client = self._connect()

    def _connect(self):
        kwargs: dict[str, Any] = {
            "hosts": self.cfg.hosts,
            "verify_certs": self.cfg.verify_certs,
            "request_timeout": self.cfg.request_timeout,
        }
        if self.cfg.api_key:
            kwargs["api_key"] = self.cfg.api_key
        elif self.cfg.username and self.cfg.password:
            kwargs["basic_auth"] = (self.cfg.username, self.cfg.password)
        return Elasticsearch(**kwargs)

    def _safe(self, fn, label: str, default: Any):
        try:
            res = fn()
            # New client returns ObjectApiResponse; `.body` gives the dict.
            return getattr(res, "body", res)
        except Exception as e:
            log.warning("%s failed: %s", label, e)
            return {"_error": str(e)} if isinstance(default, dict) else default

    def collect(self) -> dict[str, Any]:
        c = self._client
        snap: dict[str, Any] = {
            "health": self._safe(lambda: c.cluster.health(), "cluster.health", {}),
            "cluster_stats": self._safe(lambda: c.cluster.stats(), "cluster.stats", {}),
            "nodes_stats": self._safe(
                lambda: c.nodes.stats(metric=["jvm", "os", "fs", "thread_pool",
                                             "indices", "breaker"]),
                "nodes.stats", {},
            ),
            "nodes_info": self._safe(
                lambda: c.nodes.info(metric=["settings", "jvm", "os", "plugins"]),
                "nodes.info", {},
            ),
            "indices_stats": self._safe(
                lambda: c.indices.stats(metric=["docs", "store", "indexing",
                                                "search", "segments", "merges",
                                                "refresh", "flush"]),
                "indices.stats", {},
            ),
            "cat_shards": self._safe(
                lambda: c.cat.shards(format="json", bytes="b", h="index,shard,prirep,state,docs,store,node"),
                "cat.shards", [],
            ),
            "cat_indices": self._safe(
                lambda: c.cat.indices(format="json", bytes="b",
                                      h="index,health,status,pri,rep,docs.count,store.size,creation.date"),
                "cat.indices", [],
            ),
            "cat_pending": self._safe(
                lambda: c.cat.pending_tasks(format="json"),
                "cat.pending_tasks", [],
            ),
            "allocation_explain": self._safe(
                lambda: c.cluster.allocation_explain(), "allocation.explain", {},
            ),
            "settings": self._safe(
                lambda: c.cluster.get_settings(include_defaults=True, flat_settings=True),
                "cluster.get_settings", {},
            ),
            "ilm": self._safe(lambda: c.ilm.get_lifecycle(), "ilm.get_lifecycle", {}),
        }
        return snap
