"""Redis snapshot collector.

All data collection happens here. Agents consume the snapshot; they do not
hit the cluster themselves. This keeps agents fast, deterministic, and
unit-testable with fixtures.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

try:
    import redis
    from redis.cluster import RedisCluster, ClusterNode
except ImportError:
    redis = None  # deferred; raised when collect() is called

log = logging.getLogger(__name__)


@dataclass
class RedisConnectionConfig:
    host: str = "localhost"
    port: int = 6379
    password: str | None = None
    tls: bool = False
    cluster_mode: bool = False
    socket_timeout: float = 5.0
    # When sampling the keyspace we SCAN a capped number of keys per node.
    sample_size: int = 2000
    # Keys larger than this (bytes) are flagged.
    big_key_bytes: int = 1_000_000
    # Slowlog entries to pull.
    slowlog_limit: int = 128


class RedisCollector:
    def __init__(self, cfg: RedisConnectionConfig):
        if redis is None:
            raise RuntimeError("redis-py not installed. pip install redis")
        self.cfg = cfg
        self._client = self._connect()

    def _connect(self):
        kwargs = {
            "host": self.cfg.host,
            "port": self.cfg.port,
            "password": self.cfg.password,
            "ssl": self.cfg.tls,
            "socket_timeout": self.cfg.socket_timeout,
            "decode_responses": True,
        }
        if self.cfg.cluster_mode:
            startup = [ClusterNode(self.cfg.host, self.cfg.port)]
            return RedisCluster(
                startup_nodes=startup,
                password=self.cfg.password,
                ssl=self.cfg.tls,
                socket_timeout=self.cfg.socket_timeout,
                decode_responses=True,
            )
        return redis.Redis(**kwargs)

    # ---- individual probes -------------------------------------------------

    def _info(self) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for section in ("server", "clients", "memory", "persistence",
                        "stats", "replication", "cpu", "commandstats", "keyspace"):
            try:
                out[section] = self._client.info(section)
            except Exception as e:
                log.warning("INFO %s failed: %s", section, e)
                out[section] = {"_error": str(e)}
        return out

    def _config(self) -> dict[str, Any]:
        try:
            return self._client.config_get("*")
        except Exception as e:
            log.warning("CONFIG GET failed: %s", e)
            return {"_error": str(e)}

    def _slowlog(self) -> list[dict[str, Any]]:
        try:
            entries = self._client.slowlog_get(self.cfg.slowlog_limit)
            return [
                {
                    "id": e.get("id"),
                    "start_time": e.get("start_time"),
                    "duration_us": e.get("duration"),
                    "command": " ".join(str(p) for p in (e.get("command") or [])[:8]),
                }
                for e in entries
            ]
        except Exception as e:
            log.warning("SLOWLOG GET failed: %s", e)
            return []

    def _latency(self) -> dict[str, Any]:
        try:
            latest = self._client.execute_command("LATENCY", "LATEST") or []
            return {"latest": latest}
        except Exception as e:
            return {"_error": str(e)}

    def _client_list(self) -> list[dict[str, Any]]:
        try:
            return self._client.client_list()
        except Exception as e:
            log.warning("CLIENT LIST failed: %s", e)
            return []

    def _cluster_topology(self) -> dict[str, Any]:
        if not self.cfg.cluster_mode:
            return {"enabled": False}
        try:
            return {
                "enabled": True,
                "info": self._client.execute_command("CLUSTER", "INFO"),
                "nodes": self._client.execute_command("CLUSTER", "NODES"),
            }
        except Exception as e:
            return {"enabled": True, "_error": str(e)}

    def _sample_keys(self) -> dict[str, Any]:
        """SCAN a capped sample, then MEMORY USAGE each key.

        We do NOT use KEYS * — it blocks the server. SCAN with a sensible
        count is safe in production.
        """
        big_keys: list[dict[str, Any]] = []
        type_counts: dict[str, int] = {}
        sampled = 0
        try:
            cursor = 0
            while sampled < self.cfg.sample_size:
                cursor, batch = self._client.scan(cursor=cursor, count=200)
                for key in batch:
                    sampled += 1
                    try:
                        t = self._client.type(key)
                        type_counts[t] = type_counts.get(t, 0) + 1
                        size = self._client.memory_usage(key) or 0
                        if size >= self.cfg.big_key_bytes:
                            big_keys.append({"key": key, "type": t, "bytes": size})
                    except Exception:
                        continue
                    if sampled >= self.cfg.sample_size:
                        break
                if cursor == 0:
                    break
        except Exception as e:
            log.warning("keyspace sampling failed: %s", e)
            return {"_error": str(e), "sampled": sampled, "big_keys": big_keys,
                    "type_counts": type_counts}
        # Largest-first for the UI.
        big_keys.sort(key=lambda x: x["bytes"], reverse=True)
        return {"sampled": sampled, "big_keys": big_keys[:25], "type_counts": type_counts}

    # ---- public API --------------------------------------------------------

    def collect(self) -> dict[str, Any]:
        snap: dict[str, Any] = {
            "info": self._info(),
            "config": self._config(),
            "slowlog": self._slowlog(),
            "latency": self._latency(),
            "clients": self._client_list(),
            "cluster": self._cluster_topology(),
            "keyspace_sample": self._sample_keys(),
        }
        return snap
