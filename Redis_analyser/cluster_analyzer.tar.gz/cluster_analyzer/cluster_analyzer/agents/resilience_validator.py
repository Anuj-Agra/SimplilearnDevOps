"""Resilience Validator — persistence integrity, snapshot recency, backup posture."""
from __future__ import annotations

import time
from typing import Any

from ..base_agent import BaseAgent
from ..models import Finding, Severity, Area


class ResilienceValidator(BaseAgent):
    name = "ResilienceValidator"

    RDB_STALE_HOURS = 24
    SNAPSHOT_STALE_HOURS = 24

    def analyze(self, r: dict[str, Any], e: dict[str, Any]) -> list[Finding]:
        return self._redis(r) + self._elastic(e)

    # --- Redis ---
    def _redis(self, r: dict[str, Any]) -> list[Finding]:
        findings: list[Finding] = []
        pers = (r.get("info") or {}).get("persistence") or {}

        last_save = self._safe_int(pers.get("rdb_last_save_time"))
        if last_save > 0:
            age_h = (time.time() - last_save) / 3600
            if age_h > self.RDB_STALE_HOURS:
                findings.append(Finding(
                    agent=self.name, system="redis", area=Area.RESILIENCE, severity=Severity.HIGH,
                    title=f"Last RDB snapshot is {age_h:.1f} hours old",
                    detail="Stale snapshots widen the RPO during a full-node loss.",
                    recommendation="Check the save schedule and bgsave errors; ensure replicas or "
                                   "scheduled backups keep snapshots fresh.",
                    evidence={"last_save_epoch": last_save, "age_hours": age_h},
                ))

        bgsave_err = self._safe_int(pers.get("rdb_last_bgsave_status") == "err")
        if pers.get("rdb_last_bgsave_status") == "err":
            findings.append(Finding(
                agent=self.name, system="redis", area=Area.RESILIENCE, severity=Severity.CRITICAL,
                title="Last Redis BGSAVE failed",
                detail="Snapshot persistence is currently broken.",
                recommendation="Check disk space, permissions, and errors in redis.log.",
                evidence={"bgsave_status": pers.get("rdb_last_bgsave_status")},
            ))

        aof_enabled = str(pers.get("aof_enabled")) in ("1", "True", "true")
        aof_rewrite_err = pers.get("aof_last_bgrewrite_status") == "err"
        if aof_enabled and aof_rewrite_err:
            findings.append(Finding(
                agent=self.name, system="redis", area=Area.RESILIENCE, severity=Severity.HIGH,
                title="Last AOF rewrite failed",
                detail="AOF rewrite is how Redis compacts the append log. Failures mean the AOF grows unbounded.",
                recommendation="Investigate disk, permissions, memory headroom during fork.",
                evidence={"aof_rewrite_status": pers.get("aof_last_bgrewrite_status")},
            ))
        return findings

    # --- Elasticsearch ---
    def _elastic(self, e: dict[str, Any]) -> list[Finding]:
        findings: list[Finding] = []
        ilm = e.get("ilm") or {}
        if not ilm or (isinstance(ilm, dict) and ilm.get("_error")):
            findings.append(Finding(
                agent=self.name, system="elasticsearch", area=Area.RESILIENCE, severity=Severity.MEDIUM,
                title="No ILM policies retrieved",
                detail="Without ILM, indices grow forever and eventually fill disk.",
                recommendation="Define ILM policies for time-series indices (hot/warm/cold/delete phases).",
                evidence={"ilm_keys": list(ilm.keys()) if isinstance(ilm, dict) else None},
            ))

        # Unassigned primary shards = data at risk right now.
        health = e.get("health") or {}
        unassigned = self._safe_int(health.get("unassigned_shards"))
        initializing = self._safe_int(health.get("initializing_shards"))
        if unassigned > 0:
            findings.append(Finding(
                agent=self.name, system="elasticsearch", area=Area.RESILIENCE, severity=Severity.HIGH,
                title=f"{unassigned} unassigned shards",
                detail=f"{initializing} initializing shards in flight.",
                recommendation="/_cluster/allocation/explain to diagnose. Common causes: disk watermark, "
                               "awareness attributes, or max_retries exceeded.",
                evidence={"unassigned": unassigned, "initializing": initializing},
            ))

        # Cluster-level snapshot recency is only visible via snapshot API; we include a hint
        # to configure that explicitly because the default collector doesn't fetch it.
        return findings
