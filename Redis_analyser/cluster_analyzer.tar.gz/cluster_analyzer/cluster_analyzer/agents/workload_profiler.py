"""Workload Profiler — hot/big keys, mapping bloat, shard count vs heap."""
from __future__ import annotations

from typing import Any

from ..base_agent import BaseAgent
from ..models import Finding, Severity, Area


class WorkloadProfiler(BaseAgent):
    name = "WorkloadProfiler"

    SHARDS_PER_GB_HEAP_MAX = 20     # community rule of thumb
    MAPPING_FIELDS_WARN = 1000
    MAPPING_FIELDS_HIGH = 5000

    def analyze(self, r: dict[str, Any], e: dict[str, Any]) -> list[Finding]:
        return self._redis(r) + self._elastic(e)

    # --- Redis ---
    def _redis(self, r: dict[str, Any]) -> list[Finding]:
        findings: list[Finding] = []
        sample = r.get("keyspace_sample") or {}
        big_keys = sample.get("big_keys") or []
        if big_keys:
            worst = big_keys[0]
            findings.append(Finding(
                agent=self.name, system="redis", area=Area.WORKLOAD, severity=Severity.HIGH,
                title=f"{len(big_keys)} big keys detected (worst: {worst['key']} @ {worst['bytes']/1024**2:.1f} MB)",
                detail="Big keys block the single Redis thread on DEL, expiry, and replication.",
                recommendation="Split into smaller structures (hash fields, shards), or lazy-delete with UNLINK.",
                evidence={"big_keys": big_keys[:10]},
            ))

        # Most commonly seen non-cache anti-pattern: persistent Redis used as a queue with LRANGE 0 -1.
        # Surface key-type imbalance for awareness.
        type_counts = sample.get("type_counts") or {}
        total = sum(type_counts.values()) or 1
        for t, c in type_counts.items():
            if t in ("list", "set", "zset") and c / total > 0.6:
                findings.append(Finding(
                    agent=self.name, system="redis", area=Area.WORKLOAD, severity=Severity.INFO,
                    title=f"{c/total:.0%} of sampled keys are {t}",
                    detail="Worth double-checking access patterns — large collections are a common "
                           "source of O(N) operations.",
                    recommendation="If you iterate these, use SCAN-family commands and chunked reads.",
                    evidence={"type_counts": type_counts, "sampled": total},
                ))
        return findings

    # --- Elasticsearch ---
    def _elastic(self, e: dict[str, Any]) -> list[Finding]:
        findings: list[Finding] = []
        cluster_stats = e.get("cluster_stats") or {}
        indices_block = cluster_stats.get("indices") or {}
        total_shards = self._safe_int(((cluster_stats.get("indices") or {}).get("shards") or {}).get("total"))

        # Heap across data nodes.
        nodes = ((e.get("nodes_stats") or {}).get("nodes")) or {}
        total_heap_bytes = 0
        for n in nodes.values():
            jvm = n.get("jvm", {}).get("mem", {})
            total_heap_bytes += self._safe_int(jvm.get("heap_max_in_bytes"))
        total_heap_gb = total_heap_bytes / 1024**3 if total_heap_bytes else 0
        if total_heap_gb > 0 and total_shards > 0:
            ratio = total_shards / total_heap_gb
            if ratio > self.SHARDS_PER_GB_HEAP_MAX:
                findings.append(Finding(
                    agent=self.name, system="elasticsearch", area=Area.WORKLOAD, severity=Severity.HIGH,
                    title=f"{ratio:.1f} shards per GB of cluster heap (threshold {self.SHARDS_PER_GB_HEAP_MAX})",
                    detail=f"total_shards={total_shards}, total_heap={total_heap_gb:.1f} GB",
                    recommendation="Reduce shard count: rollover older indices, use ILM to shrink, or increase primaries only on the largest indices.",
                    evidence={"shards": total_shards, "heap_gb": total_heap_gb, "ratio": ratio},
                ))

        # Mapping / field explosion.
        field_stats = (indices_block.get("mappings") or {}).get("total_field_count")
        total_fields = self._safe_int(field_stats)
        if total_fields >= self.MAPPING_FIELDS_HIGH:
            sev = Severity.HIGH
        elif total_fields >= self.MAPPING_FIELDS_WARN:
            sev = Severity.MEDIUM
        else:
            sev = None
        if sev:
            findings.append(Finding(
                agent=self.name, system="elasticsearch", area=Area.WORKLOAD, severity=sev,
                title=f"Cluster has {total_fields:,} mapped fields",
                detail="Field explosion bloats cluster state and slows every master operation.",
                recommendation="Disable dynamic mapping, use runtime fields for rarely-queried data, "
                               "or use flattened type for high-cardinality object payloads.",
                evidence={"total_fields": total_fields},
            ))

        # Tiny-shard indices: hurt cluster state with little value.
        tiny = 0
        for idx in (e.get("cat_indices") or []):
            if not isinstance(idx, dict):
                continue
            size = self._safe_int(idx.get("store.size"))
            pri = self._safe_int(idx.get("pri"))
            if pri > 0 and 0 < size < 50 * 1024 * 1024:  # <50MB
                tiny += 1
        if tiny >= 20:
            findings.append(Finding(
                agent=self.name, system="elasticsearch", area=Area.WORKLOAD, severity=Severity.MEDIUM,
                title=f"{tiny} indices are under 50 MB",
                detail="Tiny indices with multiple primaries waste cluster state and memory.",
                recommendation="Consolidate via shrink / reindex, or roll them up with ILM.",
                evidence={"tiny_index_count": tiny},
            ))
        return findings
