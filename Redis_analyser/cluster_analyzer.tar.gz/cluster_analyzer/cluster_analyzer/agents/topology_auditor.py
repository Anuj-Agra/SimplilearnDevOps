"""Topology Auditor — replica placement, shard balance, quorum, split-brain risk."""
from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any

from ..base_agent import BaseAgent
from ..models import Finding, Severity, Area


class TopologyAuditor(BaseAgent):
    name = "TopologyAuditor"

    REPL_LAG_BYTES_HIGH = 50 * 1024 * 1024  # 50MB behind master

    def analyze(self, r: dict[str, Any], e: dict[str, Any]) -> list[Finding]:
        out: list[Finding] = []
        out += self._redis(r)
        out += self._elastic(e)
        return out

    # --- Redis ---
    def _redis(self, r: dict[str, Any]) -> list[Finding]:
        findings: list[Finding] = []
        repl = (r.get("info") or {}).get("replication") or {}
        role = repl.get("role")
        connected_slaves = self._safe_int(repl.get("connected_slaves"))

        if role == "master" and connected_slaves == 0:
            findings.append(Finding(
                agent=self.name, system="redis", area=Area.TOPOLOGY, severity=Severity.HIGH,
                title="Redis master has no connected replicas",
                detail="Any node loss = data loss + outage. Not a valid HA posture.",
                recommendation="Add at least one replica; prefer two for sentinel-based failover quorum.",
                evidence={"role": role, "slaves": connected_slaves},
            ))

        # Replica lag
        master_offset = self._safe_int(repl.get("master_repl_offset"))
        for i in range(connected_slaves):
            slave_info = repl.get(f"slave{i}")
            if not isinstance(slave_info, dict):
                continue
            slave_offset = self._safe_int(slave_info.get("offset"))
            lag = master_offset - slave_offset
            if lag > self.REPL_LAG_BYTES_HIGH:
                findings.append(Finding(
                    agent=self.name, system="redis", area=Area.TOPOLOGY, severity=Severity.HIGH,
                    title=f"Replica {slave_info.get('ip')} is {lag:,}B behind master",
                    detail="Large replication lag means RPO is not what you think it is.",
                    recommendation="Check replica CPU/network, repl-backlog-size, and whether "
                                   "the replica is being used for heavy read traffic.",
                    evidence={"replica": slave_info, "lag_bytes": lag},
                ))

        # Cluster mode: failed / handshake nodes
        cluster = r.get("cluster") or {}
        if cluster.get("enabled"):
            nodes_raw = cluster.get("nodes") or ""
            bad_states = [line for line in str(nodes_raw).splitlines()
                          if any(s in line for s in ("fail", "handshake", "noaddr"))]
            if bad_states:
                findings.append(Finding(
                    agent=self.name, system="redis", area=Area.TOPOLOGY, severity=Severity.CRITICAL,
                    title=f"{len(bad_states)} Redis cluster nodes in a bad state",
                    detail="Nodes in fail/handshake/noaddr impair cluster availability and shard coverage.",
                    recommendation="CLUSTER FORGET stale nodes; rejoin healthy ones; verify gossip port connectivity.",
                    evidence={"bad_lines": bad_states},
                ))
        return findings

    # --- Elasticsearch ---
    def _elastic(self, e: dict[str, Any]) -> list[Finding]:
        findings: list[Finding] = []
        health = e.get("health") or {}
        status = health.get("status")
        if status == "red":
            findings.append(Finding(
                agent=self.name, system="elasticsearch", area=Area.TOPOLOGY, severity=Severity.CRITICAL,
                title="Elasticsearch cluster status is RED",
                detail=f"Unassigned primary shards: {health.get('unassigned_shards')}",
                recommendation="Run /_cluster/allocation/explain; this usually needs immediate hands-on triage.",
                evidence=health,
            ))
        elif status == "yellow":
            findings.append(Finding(
                agent=self.name, system="elasticsearch", area=Area.TOPOLOGY, severity=Severity.HIGH,
                title="Elasticsearch cluster status is YELLOW",
                detail=f"Replicas unassigned — HA is degraded. Unassigned: {health.get('unassigned_shards')}",
                recommendation="Usually replica count > available nodes, or allocation filters blocking assignment.",
                evidence=health,
            ))

        # Master/data/ingest node role counts
        nodes_info = ((e.get("nodes_info") or {}).get("nodes")) or {}
        role_counter: Counter = Counter()
        for n in nodes_info.values():
            for role in (n.get("roles") or []):
                role_counter[role] += 1

        master_eligible = role_counter.get("master", 0)
        if master_eligible and master_eligible % 2 == 0:
            findings.append(Finding(
                agent=self.name, system="elasticsearch", area=Area.TOPOLOGY, severity=Severity.HIGH,
                title=f"{master_eligible} master-eligible nodes — even number",
                detail="Even counts are a split-brain risk on network partitions.",
                recommendation="Use 3 or 5 dedicated master-eligible nodes.",
                evidence={"roles": dict(role_counter)},
            ))
        if master_eligible < 3 and len(nodes_info) >= 3:
            findings.append(Finding(
                agent=self.name, system="elasticsearch", area=Area.TOPOLOGY, severity=Severity.HIGH,
                title=f"Only {master_eligible} master-eligible node(s)",
                detail="Fewer than 3 master-eligible nodes means no tolerance for a single master failure.",
                recommendation="Promote 3 dedicated master-eligible nodes (ideally no data/ingest role).",
                evidence={"roles": dict(role_counter)},
            ))

        # Shard distribution skew across data nodes.
        shards_per_node: defaultdict[str, int] = defaultdict(int)
        for shard in (e.get("cat_shards") or []):
            if isinstance(shard, dict) and shard.get("state") == "STARTED" and shard.get("node"):
                shards_per_node[shard["node"]] += 1
        if len(shards_per_node) >= 2:
            counts = list(shards_per_node.values())
            hi, lo = max(counts), min(counts)
            if hi > 0 and (hi - lo) / hi >= 0.3:
                findings.append(Finding(
                    agent=self.name, system="elasticsearch", area=Area.TOPOLOGY, severity=Severity.MEDIUM,
                    title=f"Shard distribution skewed: {lo}…{hi} shards/node",
                    detail="Uneven load, hotspot risk, and longer recovery on the heavy node.",
                    recommendation="Check allocation filters, shard awareness, and disk-based allocation settings.",
                    evidence={"distribution": dict(shards_per_node)},
                ))
        return findings
