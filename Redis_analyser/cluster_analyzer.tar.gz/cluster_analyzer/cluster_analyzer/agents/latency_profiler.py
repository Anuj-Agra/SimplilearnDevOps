"""Latency Profiler — slow queries, thread pool rejections, Redis latency events."""
from __future__ import annotations

from collections import Counter
from typing import Any

from ..base_agent import BaseAgent
from ..models import Finding, Severity, Area


class LatencyProfiler(BaseAgent):
    name = "LatencyProfiler"

    SLOWLOG_SAMPLE_COUNT = 10     # flag if slowlog has >= this many entries in the window
    SLOW_CMD_US_HIGH = 100_000    # 100ms
    TP_REJECT_WARN = 1
    TP_REJECT_HIGH = 100

    def analyze(self, r: dict[str, Any], e: dict[str, Any]) -> list[Finding]:
        out: list[Finding] = []
        out += self._redis(r)
        out += self._elastic(e)
        return out

    # --- Redis ---
    def _redis(self, r: dict[str, Any]) -> list[Finding]:
        findings: list[Finding] = []
        slowlog = r.get("slowlog") or []
        if len(slowlog) >= self.SLOWLOG_SAMPLE_COUNT:
            # Group slow commands by first token.
            top = Counter(entry["command"].split(" ", 1)[0] for entry in slowlog).most_common(5)
            worst = max(slowlog, key=lambda x: x.get("duration_us", 0))
            sev = Severity.HIGH if worst.get("duration_us", 0) > self.SLOW_CMD_US_HIGH else Severity.MEDIUM
            findings.append(Finding(
                agent=self.name, system="redis", area=Area.LATENCY, severity=sev,
                title=f"{len(slowlog)} entries in Redis slowlog",
                detail=(f"Top offenders: {top}. Worst: {worst.get('command')} "
                        f"at {worst.get('duration_us')}µs."),
                recommendation="Watch for KEYS, SMEMBERS on huge sets, LRANGE 0 -1, or Lua scripts "
                               "holding the single thread. Replace with SCAN / chunked reads.",
                evidence={"count": len(slowlog), "top": top, "worst": worst},
            ))

        # LATENCY LATEST events
        latest = (r.get("latency") or {}).get("latest") or []
        if latest:
            findings.append(Finding(
                agent=self.name, system="redis", area=Area.LATENCY, severity=Severity.MEDIUM,
                title=f"{len(latest)} active latency events on Redis",
                detail=f"Events: {latest}",
                recommendation="Run LATENCY DOCTOR for diagnostics. Common culprits: fork for RDB, "
                               "AOF rewrite, THP enabled, or swap.",
                evidence={"events": latest},
            ))

        # Excessive connected clients — can cause socket latency spikes.
        clients = (r.get("info") or {}).get("clients") or {}
        connected = self._safe_int(clients.get("connected_clients"))
        if connected > 5000:
            findings.append(Finding(
                agent=self.name, system="redis", area=Area.LATENCY, severity=Severity.MEDIUM,
                title=f"{connected:,} connected Redis clients",
                detail="Very high client counts increase context switching and may indicate "
                       "missing pooling upstream.",
                recommendation="Introduce connection pooling in application tier; consider a proxy "
                               "(Envoy/Twemproxy) to multiplex.",
                evidence={"connected_clients": connected},
            ))
        return findings

    # --- Elasticsearch ---
    def _elastic(self, e: dict[str, Any]) -> list[Finding]:
        findings: list[Finding] = []
        nodes = ((e.get("nodes_stats") or {}).get("nodes")) or {}

        for node_id, node in nodes.items():
            name = node.get("name", node_id)
            pools = node.get("thread_pool") or {}
            for pool_name, stats in pools.items():
                rejected = self._safe_int(stats.get("rejected"))
                if rejected >= self.TP_REJECT_HIGH:
                    sev = Severity.HIGH
                elif rejected >= self.TP_REJECT_WARN:
                    sev = Severity.MEDIUM
                else:
                    continue
                findings.append(Finding(
                    agent=self.name, system="elasticsearch", area=Area.LATENCY, severity=sev,
                    title=f"Thread pool '{pool_name}' on '{name}' rejected {rejected:,} tasks",
                    detail="Rejections mean the pool's queue was full — clients saw 429/503.",
                    recommendation="Investigate upstream load patterns. For search pools, "
                                   "check for expensive queries; for write pools, batch bulk requests.",
                    evidence={"node": name, "pool": pool_name, "rejected": rejected},
                ))

            breakers = node.get("breakers") or {}
            for bname, b in breakers.items():
                tripped = self._safe_int(b.get("tripped"))
                if tripped > 0:
                    findings.append(Finding(
                        agent=self.name, system="elasticsearch", area=Area.LATENCY, severity=Severity.HIGH,
                        title=f"Circuit breaker '{bname}' tripped {tripped} times on '{name}'",
                        detail="Requests were aborted to protect the node; users saw failures.",
                        recommendation="Review the offending queries (usually large aggs / fielddata). "
                                       "Increase breaker limits only as a last resort.",
                        evidence={"node": name, "breaker": bname, "tripped": tripped},
                    ))

        # Pending tasks on master — usually indicates slow cluster state updates.
        pending = e.get("cat_pending") or []
        if len(pending) > 10:
            findings.append(Finding(
                agent=self.name, system="elasticsearch", area=Area.LATENCY, severity=Severity.HIGH,
                title=f"{len(pending)} pending cluster tasks on master",
                detail="Master is backlogged — likely mapping updates, shard allocation, or template creation bursts.",
                recommendation="Check task priorities; stop auto-creating indices per tenant; "
                               "switch to composable index templates.",
                evidence={"count": len(pending), "sample": pending[:5]},
            ))
        return findings
