"""Config Linter — compares live config against a policy baseline."""
from __future__ import annotations

from typing import Any

from ..base_agent import BaseAgent
from ..models import Finding, Severity, Area


class ConfigLinter(BaseAgent):
    """Validates config against a baseline dict passed at construction time.

    Baseline shape (see config/baseline.yaml):
      {
        "redis": {
          "maxmemory-policy": {"allowed": ["allkeys-lru","volatile-lru","noeviction"],
                                "severity": "HIGH"},
          ...
        },
        "elasticsearch_cluster": {
          "action.destructive_requires_name": {"equals": "true", "severity": "MEDIUM"},
        }
      }
    """
    name = "ConfigLinter"

    def __init__(self, baseline: dict[str, Any] | None = None):
        self.baseline = baseline or {}

    def analyze(self, r: dict[str, Any], e: dict[str, Any]) -> list[Finding]:
        return self._redis(r) + self._elastic(e)

    @staticmethod
    def _sev_from_str(s: str | None) -> Severity:
        if not s: return Severity.MEDIUM
        try:  return Severity(s.upper())
        except ValueError: return Severity.MEDIUM

    def _check(self, system: str, key: str, value: Any, rule: dict[str, Any]) -> Finding | None:
        sev = self._sev_from_str(rule.get("severity"))
        if "equals" in rule and str(value) != str(rule["equals"]):
            return Finding(
                agent=self.name, system=system, area=Area.CONFIG, severity=sev,
                title=f"{system} config '{key}' = {value!r}, expected {rule['equals']!r}",
                detail=rule.get("rationale", ""),
                recommendation=rule.get("fix", f"Set {key}={rule['equals']}."),
                evidence={"key": key, "actual": value, "expected": rule["equals"]},
            )
        if "allowed" in rule and str(value) not in [str(a) for a in rule["allowed"]]:
            return Finding(
                agent=self.name, system=system, area=Area.CONFIG, severity=sev,
                title=f"{system} config '{key}' = {value!r} not in allowed set",
                detail=rule.get("rationale", f"Allowed: {rule['allowed']}"),
                recommendation=rule.get("fix", f"Set {key} to one of {rule['allowed']}."),
                evidence={"key": key, "actual": value, "allowed": rule["allowed"]},
            )
        if "min" in rule:
            try:
                if float(value) < float(rule["min"]):
                    return Finding(
                        agent=self.name, system=system, area=Area.CONFIG, severity=sev,
                        title=f"{system} config '{key}' = {value} below min {rule['min']}",
                        detail=rule.get("rationale", ""),
                        recommendation=rule.get("fix", f"Raise {key} to at least {rule['min']}."),
                        evidence={"key": key, "actual": value, "min": rule["min"]},
                    )
            except (TypeError, ValueError):
                pass
        if "max" in rule:
            try:
                if float(value) > float(rule["max"]):
                    return Finding(
                        agent=self.name, system=system, area=Area.CONFIG, severity=sev,
                        title=f"{system} config '{key}' = {value} above max {rule['max']}",
                        detail=rule.get("rationale", ""),
                        recommendation=rule.get("fix", f"Lower {key} to at most {rule['max']}."),
                        evidence={"key": key, "actual": value, "max": rule["max"]},
                    )
            except (TypeError, ValueError):
                pass
        return None

    def _redis(self, r: dict[str, Any]) -> list[Finding]:
        findings: list[Finding] = []
        live = r.get("config") or {}
        rules = (self.baseline.get("redis") or {})
        for key, rule in rules.items():
            if key in live:
                f = self._check("redis", key, live[key], rule)
                if f:
                    findings.append(f)

        # A couple of hard-coded checks that are always worth flagging:
        if str(live.get("protected-mode", "")).lower() == "no" and not live.get("requirepass"):
            findings.append(Finding(
                agent=self.name, system="redis", area=Area.CONFIG, severity=Severity.CRITICAL,
                title="Redis protected-mode=no with no password",
                detail="Exposed Redis is one of the most common infosec incidents.",
                recommendation="Enable requirepass (or ACLs) and/or bind to private interfaces only.",
                evidence={"protected_mode": live.get("protected-mode")},
            ))
        if str(live.get("appendonly", "")).lower() == "no" and str(live.get("save", "")).strip() == "":
            findings.append(Finding(
                agent=self.name, system="redis", area=Area.CONFIG, severity=Severity.HIGH,
                title="Redis has no persistence (AOF off, RDB save disabled)",
                detail="A restart loses everything. Fine for pure cache, not fine for anything else.",
                recommendation="Enable AOF (appendonly yes, everysec) for a durability baseline, plus RDB for snapshots.",
                evidence={"appendonly": live.get("appendonly"), "save": live.get("save")},
            ))
        return findings

    def _elastic(self, e: dict[str, Any]) -> list[Finding]:
        findings: list[Finding] = []
        settings = e.get("settings") or {}
        # Flatten persistent+transient+defaults.
        live: dict[str, Any] = {}
        for scope in ("defaults", "persistent", "transient"):
            section = settings.get(scope) or {}
            if isinstance(section, dict):
                live.update(section)
        rules = self.baseline.get("elasticsearch_cluster") or {}
        for key, rule in rules.items():
            if key in live:
                f = self._check("elasticsearch", key, live[key], rule)
                if f:
                    findings.append(f)

        # Per-index settings come through indices_stats; we only check a simple proxy.
        idx_rules = self.baseline.get("elasticsearch_index") or {}
        indices = ((e.get("indices_stats") or {}).get("indices")) or {}
        for idx_name, _ in indices.items():
            # We don't have per-index settings in this snapshot by default.
            # Users can extend the collector to fetch indices.get_settings for targeted checks.
            for _key, _rule in idx_rules.items():
                pass
        return findings
