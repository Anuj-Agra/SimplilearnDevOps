"""Capacity Analyst — memory/heap headroom, evictions, disk, shard sizing."""
from __future__ import annotations

from typing import Any

from ..base_agent import BaseAgent
from ..models import Finding, Severity, Area


class CapacityAnalyst(BaseAgent):
    name = "CapacityAnalyst"

    # ---- thresholds (tunable) ----
    REDIS_MEM_WARN = 0.80
    REDIS_MEM_CRIT = 0.92
    ES_HEAP_WARN = 0.75
    ES_HEAP_CRIT = 0.85
    ES_DISK_WARN = 0.80
    ES_DISK_CRIT = 0.90
    SHARD_TOO_LARGE_GB = 50
    SHARD_TOO_SMALL_MB = 100

    def analyze(self, r: dict[str, Any], e: dict[str, Any]) -> list[Finding]:
        out: list[Finding] = []
        out += self._redis(r)
        out += self._elastic(e)
        return out

    # --- Redis ---
    def _redis(self, r: dict[str, Any]) -> list[Finding]:
        findings: list[Finding] = []
        mem = (r.get("info") or {}).get("memory") or {}
        stats = (r.get("info") or {}).get("stats") or {}

        used = self._safe_int(mem.get("used_memory"))
        maxmem = self._safe_int(mem.get("maxmemory"))
        if maxmem > 0 and used > 0:
            ratio = used / maxmem
            if ratio >= self.REDIS_MEM_CRIT:
                sev = Severity.CRITICAL
            elif ratio >= self.REDIS_MEM_WARN:
                sev = Severity.HIGH
            else:
                sev = None
            if sev:
                findings.append(Finding(
                    agent=self.name, system="redis", area=Area.CAPACITY, severity=sev,
                    title=f"Redis memory at {ratio:.0%} of maxmemory",
                    detail=f"used_memory={used:,}B, maxmemory={maxmem:,}B",
                    recommendation=("Scale up, shard, or shed load. Verify eviction policy "
                                    "is appropriate for workload before you hit the wall."),
                    evidence={"used_memory": used, "maxmemory": maxmem, "ratio": ratio},
                ))
        elif maxmem == 0:
            findings.append(Finding(
                agent=self.name, system="redis", area=Area.CAPACITY, severity=Severity.HIGH,
                title="Redis has no maxmemory limit set",
                detail="maxmemory=0 means Redis can grow until the OS OOM-kills it.",
                recommendation="Set maxmemory to ~70–80% of instance RAM and pick a sensible "
                               "eviction policy (allkeys-lru for cache, noeviction for source-of-truth).",
                evidence={"maxmemory": maxmem},
            ))

        evicted = self._safe_int(stats.get("evicted_keys"))
        if evicted > 0:
            findings.append(Finding(
                agent=self.name, system="redis", area=Area.CAPACITY, severity=Severity.MEDIUM,
                title=f"Redis has evicted {evicted:,} keys since start",
                detail="Ongoing eviction means working set exceeds maxmemory.",
                recommendation="Raise maxmemory, add nodes, or shorten TTLs on low-value keys.",
                evidence={"evicted_keys": evicted},
            ))

        frag = self._safe_float(mem.get("mem_fragmentation_ratio"))
        if frag > 1.5 and used > 100 * 1024 * 1024:
            findings.append(Finding(
                agent=self.name, system="redis", area=Area.CAPACITY, severity=Severity.MEDIUM,
                title=f"Redis memory fragmentation ratio is {frag:.2f}",
                detail="Values >1.5 suggest the allocator is holding memory the dataset isn't using.",
                recommendation="Enable activedefrag, or schedule a rolling restart of replicas during a maintenance window.",
                evidence={"fragmentation": frag},
            ))
        return findings

    # --- Elasticsearch ---
    def _elastic(self, e: dict[str, Any]) -> list[Finding]:
        findings: list[Finding] = []
        nodes = ((e.get("nodes_stats") or {}).get("nodes")) or {}

        for node_id, node in nodes.items():
            name = node.get("name", node_id)
            jvm = node.get("jvm", {}).get("mem", {})
            heap_used = self._safe_int(jvm.get("heap_used_in_bytes"))
            heap_max = self._safe_int(jvm.get("heap_max_in_bytes"))
            if heap_max > 0:
                ratio = heap_used / heap_max
                if ratio >= self.ES_HEAP_CRIT:
                    sev = Severity.CRITICAL
                elif ratio >= self.ES_HEAP_WARN:
                    sev = Severity.HIGH
                else:
                    sev = None
                if sev:
                    findings.append(Finding(
                        agent=self.name, system="elasticsearch", area=Area.CAPACITY, severity=sev,
                        title=f"Node '{name}' JVM heap at {ratio:.0%}",
                        detail=f"heap_used={heap_used:,}B of heap_max={heap_max:,}B",
                        recommendation=("Reduce fielddata, cap buckets in aggs, or scale horizontally. "
                                        "Heap >32GB loses compressed oops — split the node instead."),
                        evidence={"node": name, "ratio": ratio},
                    ))

            # Disk watermarks
            fs_data = (node.get("fs") or {}).get("data") or []
            for mount in fs_data:
                total = self._safe_int(mount.get("total_in_bytes"))
                avail = self._safe_int(mount.get("available_in_bytes"))
                if total > 0:
                    used_ratio = 1 - (avail / total)
                    if used_ratio >= self.ES_DISK_CRIT:
                        sev = Severity.CRITICAL
                    elif used_ratio >= self.ES_DISK_WARN:
                        sev = Severity.HIGH
                    else:
                        sev = None
                    if sev:
                        findings.append(Finding(
                            agent=self.name, system="elasticsearch", area=Area.CAPACITY, severity=sev,
                            title=f"Node '{name}' disk at {used_ratio:.0%}",
                            detail=f"mount={mount.get('path')} used_ratio={used_ratio:.2f}",
                            recommendation="ES flood-stage watermark is 95% — at which point indices go read-only. "
                                           "Add disk, delete old indices via ILM, or force-merge cold tiers.",
                            evidence={"node": name, "path": mount.get("path"), "used_ratio": used_ratio},
                        ))

        # Shard sizing
        for shard in (e.get("cat_shards") or []):
            if not isinstance(shard, dict):
                continue
            if shard.get("prirep") != "p" or shard.get("state") != "STARTED":
                continue
            size_b = self._safe_int(shard.get("store"))
            if size_b > self.SHARD_TOO_LARGE_GB * 1024**3:
                findings.append(Finding(
                    agent=self.name, system="elasticsearch", area=Area.CAPACITY, severity=Severity.HIGH,
                    title=f"Shard {shard.get('index')}[{shard.get('shard')}] is {size_b/1024**3:.1f} GB",
                    detail=f"Shards above {self.SHARD_TOO_LARGE_GB}GB slow down recovery and rebalancing.",
                    recommendation="Rollover with ILM or reindex with more primaries.",
                    evidence={"index": shard.get("index"), "shard": shard.get("shard"), "bytes": size_b},
                ))
        return findings
