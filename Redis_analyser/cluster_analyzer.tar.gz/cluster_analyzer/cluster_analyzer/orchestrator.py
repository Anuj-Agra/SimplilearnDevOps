"""Orchestrator: collect snapshots, run all agents, synthesize report."""
from __future__ import annotations

import logging
from typing import Any

from .agents import (
    CapacityAnalyst, LatencyProfiler, TopologyAuditor,
    ConfigLinter, WorkloadProfiler, ResilienceValidator,
)
from .collectors import (
    RedisCollector, RedisConnectionConfig,
    ElasticCollector, ElasticConnectionConfig,
)
from .models import ReportBundle, Finding, Severity, Area

log = logging.getLogger(__name__)


def collect_snapshots(
    redis_cfg: RedisConnectionConfig | None,
    elastic_cfg: ElasticConnectionConfig | None,
) -> tuple[dict[str, Any], dict[str, Any], list[str]]:
    """Run the two collectors and capture any errors without failing the whole run."""
    errors: list[str] = []
    redis_snap: dict[str, Any] = {}
    elastic_snap: dict[str, Any] = {}

    if redis_cfg is not None:
        try:
            redis_snap = RedisCollector(redis_cfg).collect()
        except Exception as e:
            log.exception("Redis collection failed")
            errors.append(f"redis: {e}")

    if elastic_cfg is not None:
        try:
            elastic_snap = ElasticCollector(elastic_cfg).collect()
        except Exception as e:
            log.exception("Elasticsearch collection failed")
            errors.append(f"elasticsearch: {e}")

    return redis_snap, elastic_snap, errors


def run_analysis(
    redis_snap: dict[str, Any],
    elastic_snap: dict[str, Any],
    baseline: dict[str, Any] | None = None,
    errors: list[str] | None = None,
) -> ReportBundle:
    bundle = ReportBundle(
        redis_snapshot=redis_snap,
        elastic_snapshot=elastic_snap,
        errors=list(errors or []),
    )

    agents = [
        CapacityAnalyst(),
        LatencyProfiler(),
        TopologyAuditor(),
        ConfigLinter(baseline=baseline),
        WorkloadProfiler(),
        ResilienceValidator(),
    ]
    for agent in agents:
        try:
            for f in agent.analyze(redis_snap, elastic_snap):
                bundle.add(f)
        except Exception as e:
            log.exception("Agent %s failed", agent.name)
            bundle.errors.append(f"{agent.name}: {e}")

    # Rank: highest score first, tie-break by severity enum order.
    severity_order = {s: i for i, s in enumerate([
        Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO,
    ])}
    bundle.findings.sort(key=lambda f: (-f.score, severity_order[f.severity]))
    return bundle


def summarize(bundle: ReportBundle) -> dict[str, Any]:
    """Compact aggregates for dashboards / LLM synthesis prompts."""
    by_sev: dict[str, int] = {}
    by_area: dict[str, int] = {}
    by_system: dict[str, int] = {}
    for f in bundle.findings:
        by_sev[f.severity.value] = by_sev.get(f.severity.value, 0) + 1
        by_area[f.area.value] = by_area.get(f.area.value, 0) + 1
        by_system[f.system] = by_system.get(f.system, 0) + 1

    top_actions = [
        {"title": f.title, "system": f.system, "severity": f.severity.value,
         "recommendation": f.recommendation}
        for f in bundle.findings[:10]
    ]
    return {
        "total_findings": len(bundle.findings),
        "by_severity": by_sev,
        "by_area": by_area,
        "by_system": by_system,
        "top_actions": top_actions,
        "errors": bundle.errors,
    }
