"""Streamlit dashboard for the cluster analyzer.

Run with:
    streamlit run app.py
"""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st
import yaml

from cluster_analyzer.collectors import RedisConnectionConfig, ElasticConnectionConfig
from cluster_analyzer.orchestrator import collect_snapshots, run_analysis, summarize
from cluster_analyzer.models import Severity

SEV_COLORS = {
    "CRITICAL": "#b71c1c",
    "HIGH": "#e65100",
    "MEDIUM": "#f9a825",
    "LOW": "#1976d2",
    "INFO": "#455a64",
}

st.set_page_config(page_title="Cluster Analyzer", layout="wide", page_icon="🔍")
st.title("🔍 Redis + Elasticsearch Cluster Analyzer")
st.caption("Six agents inspect a live snapshot and rank findings by impact.")


# ---- Sidebar: connection settings ----
with st.sidebar:
    st.header("Connection")

    st.subheader("Redis")
    redis_enabled = st.checkbox("Enable Redis", value=True)
    redis_host = st.text_input("Host", "localhost", disabled=not redis_enabled)
    redis_port = st.number_input("Port", value=6379, step=1, disabled=not redis_enabled)
    redis_password = st.text_input("Password", type="password", disabled=not redis_enabled)
    redis_tls = st.checkbox("TLS", value=False, disabled=not redis_enabled)
    redis_cluster = st.checkbox("Cluster mode", value=False, disabled=not redis_enabled)

    st.subheader("Elasticsearch")
    es_enabled = st.checkbox("Enable Elasticsearch", value=True)
    es_hosts_raw = st.text_area("Hosts (one per line)", "http://localhost:9200",
                                disabled=not es_enabled)
    es_user = st.text_input("Username", disabled=not es_enabled)
    es_password = st.text_input("Password (ES)", type="password", disabled=not es_enabled)
    es_api_key = st.text_input("API Key", type="password", disabled=not es_enabled)
    es_verify = st.checkbox("Verify TLS certs", value=True, disabled=not es_enabled)

    st.subheader("Baseline")
    baseline_path = st.text_input("Baseline YAML", "config/baseline.yaml")

    run_btn = st.button("Run analysis", type="primary", use_container_width=True)


def _load_baseline(path: str) -> dict:
    p = Path(path)
    if not p.exists():
        return {}
    return yaml.safe_load(p.read_text()) or {}


def _run() -> dict:
    redis_cfg = None
    if redis_enabled and redis_host:
        redis_cfg = RedisConnectionConfig(
            host=redis_host, port=int(redis_port),
            password=redis_password or None,
            tls=redis_tls, cluster_mode=redis_cluster,
        )

    elastic_cfg = None
    if es_enabled and es_hosts_raw.strip():
        hosts = [h.strip() for h in es_hosts_raw.splitlines() if h.strip()]
        elastic_cfg = ElasticConnectionConfig(
            hosts=hosts, username=es_user or None, password=es_password or None,
            api_key=es_api_key or None, verify_certs=es_verify,
        )

    redis_snap, elastic_snap, errs = collect_snapshots(redis_cfg, elastic_cfg)
    baseline = _load_baseline(baseline_path)
    bundle = run_analysis(redis_snap, elastic_snap, baseline=baseline, errors=errs)
    return bundle.to_dict()


# ---- Main panel ----
if run_btn:
    with st.spinner("Collecting snapshots and running agents..."):
        try:
            st.session_state["report"] = _run()
        except Exception as e:
            st.error(f"Run failed: {e}")

report = st.session_state.get("report")
if not report:
    st.info("Configure connections in the sidebar and click **Run analysis**.")
    st.stop()

summary_data = {
    "total_findings": len(report["findings"]),
    "by_severity": {},
    "by_area": {},
    "by_system": {},
}
for f in report["findings"]:
    summary_data["by_severity"][f["severity"]] = summary_data["by_severity"].get(f["severity"], 0) + 1
    summary_data["by_area"][f["area"]] = summary_data["by_area"].get(f["area"], 0) + 1
    summary_data["by_system"][f["system"]] = summary_data["by_system"].get(f["system"], 0) + 1

# KPI row
c1, c2, c3, c4, c5 = st.columns(5)
c1.metric("Total findings", summary_data["total_findings"])
c2.metric("Critical", summary_data["by_severity"].get("CRITICAL", 0))
c3.metric("High", summary_data["by_severity"].get("HIGH", 0))
c4.metric("Medium", summary_data["by_severity"].get("MEDIUM", 0))
c5.metric("Info/Low",
          summary_data["by_severity"].get("INFO", 0) + summary_data["by_severity"].get("LOW", 0))

if report.get("errors"):
    st.warning("Collection/agent errors: " + "; ".join(report["errors"]))

# Charts
cc1, cc2 = st.columns(2)
with cc1:
    sev_df = pd.DataFrame(
        [{"severity": k, "count": v} for k, v in summary_data["by_severity"].items()]
    )
    if not sev_df.empty:
        fig = px.bar(sev_df, x="severity", y="count", color="severity",
                     color_discrete_map=SEV_COLORS, title="Findings by Severity")
        st.plotly_chart(fig, use_container_width=True)

with cc2:
    area_df = pd.DataFrame(
        [{"area": k, "count": v} for k, v in summary_data["by_area"].items()]
    )
    if not area_df.empty:
        fig = px.pie(area_df, names="area", values="count", title="Findings by Area")
        st.plotly_chart(fig, use_container_width=True)

# Findings table + detail
st.subheader("Findings")
severity_filter = st.multiselect(
    "Filter by severity",
    options=["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"],
    default=["CRITICAL", "HIGH", "MEDIUM"],
)
system_filter = st.multiselect(
    "Filter by system",
    options=list(summary_data["by_system"].keys()),
    default=list(summary_data["by_system"].keys()),
)

filtered = [
    f for f in report["findings"]
    if f["severity"] in severity_filter and f["system"] in system_filter
]

for i, f in enumerate(filtered, 1):
    badge = SEV_COLORS.get(f["severity"], "#333")
    with st.expander(
        f"{i}. [{f['severity']}] {f['system']} — {f['title']}  (score {f['score']})"
    ):
        st.markdown(
            f"<span style='background:{badge};color:white;padding:2px 8px;border-radius:4px'>"
            f"{f['severity']}</span>  **Area:** {f['area']} · **Agent:** {f['agent']}",
            unsafe_allow_html=True,
        )
        st.write("**Detail:** ", f["detail"])
        st.write("**Recommendation:** ", f["recommendation"])
        if f.get("evidence"):
            st.caption("Evidence")
            st.json(f["evidence"])

# Raw report
with st.expander("Raw report JSON"):
    st.json(report)

st.download_button(
    "Download report.json",
    data=json.dumps(report, indent=2, default=str),
    file_name="cluster_report.json",
    mime="application/json",
)
