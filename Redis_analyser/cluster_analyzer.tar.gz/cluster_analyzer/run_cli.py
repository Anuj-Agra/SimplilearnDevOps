"""CLI runner for cluster_analyzer.

Usage:
    python run_cli.py \
        --redis-host localhost --redis-port 6379 \
        --es-host http://localhost:9200 \
        --baseline config/baseline.yaml \
        --out report.json
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path

import yaml

from cluster_analyzer.collectors import RedisConnectionConfig, ElasticConnectionConfig
from cluster_analyzer.orchestrator import collect_snapshots, run_analysis, summarize


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Redis + Elasticsearch cluster analyzer")
    # Redis
    p.add_argument("--redis-host", default=None)
    p.add_argument("--redis-port", type=int, default=6379)
    p.add_argument("--redis-password", default=os.environ.get("REDIS_PASSWORD"))
    p.add_argument("--redis-tls", action="store_true")
    p.add_argument("--redis-cluster", action="store_true")
    # Elasticsearch
    p.add_argument("--es-host", action="append", default=None,
                   help="Repeatable, e.g. --es-host http://n1:9200 --es-host http://n2:9200")
    p.add_argument("--es-user", default=None)
    p.add_argument("--es-password", default=os.environ.get("ES_PASSWORD"))
    p.add_argument("--es-api-key", default=os.environ.get("ES_API_KEY"))
    p.add_argument("--es-no-verify", action="store_true")
    # Misc
    p.add_argument("--baseline", default="config/baseline.yaml")
    p.add_argument("--out", default="report.json")
    p.add_argument("--verbose", "-v", action="store_true")
    return p


def main() -> int:
    args = build_parser().parse_args()
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    redis_cfg = None
    if args.redis_host:
        redis_cfg = RedisConnectionConfig(
            host=args.redis_host, port=args.redis_port,
            password=args.redis_password, tls=args.redis_tls,
            cluster_mode=args.redis_cluster,
        )

    elastic_cfg = None
    if args.es_host:
        elastic_cfg = ElasticConnectionConfig(
            hosts=args.es_host, username=args.es_user, password=args.es_password,
            api_key=args.es_api_key, verify_certs=not args.es_no_verify,
        )

    if redis_cfg is None and elastic_cfg is None:
        print("Provide at least one of --redis-host or --es-host.", file=sys.stderr)
        return 2

    baseline = {}
    bp = Path(args.baseline)
    if bp.exists():
        baseline = yaml.safe_load(bp.read_text()) or {}

    redis_snap, elastic_snap, errors = collect_snapshots(redis_cfg, elastic_cfg)
    bundle = run_analysis(redis_snap, elastic_snap, baseline=baseline, errors=errors)
    summary = summarize(bundle)

    Path(args.out).write_text(json.dumps(bundle.to_dict(), indent=2, default=str))

    print(f"\nCluster Analyzer — {summary['total_findings']} findings")
    print(f"By severity: {summary['by_severity']}")
    print(f"By system:   {summary['by_system']}")
    print(f"By area:     {summary['by_area']}")
    if bundle.errors:
        print(f"Collector/agent errors: {bundle.errors}")
    print("\nTop 10 actions:")
    for i, a in enumerate(summary["top_actions"], 1):
        print(f"  {i:2d}. [{a['severity']}][{a['system']}] {a['title']}")
        print(f"       → {a['recommendation']}")
    print(f"\nFull report written to {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
